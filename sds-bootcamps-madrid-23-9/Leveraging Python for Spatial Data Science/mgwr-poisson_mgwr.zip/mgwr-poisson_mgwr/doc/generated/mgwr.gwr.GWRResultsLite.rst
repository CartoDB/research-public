mgwr.gwr.GWRResultsLite
=======================

.. currentmodule:: mgwr.gwr

.. autoclass:: GWRResultsLite

   
   .. automethod:: __init__

   

   
   
   