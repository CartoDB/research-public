mgwr.gwr.GWRResults
===================

.. currentmodule:: mgwr.gwr

.. automethod:: GWRResults.sigma2


   