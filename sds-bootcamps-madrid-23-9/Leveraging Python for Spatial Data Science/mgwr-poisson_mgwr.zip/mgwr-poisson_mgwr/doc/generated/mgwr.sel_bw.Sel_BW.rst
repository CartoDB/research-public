mgwr.sel\_bw.Sel\_BW
====================

.. currentmodule:: mgwr.sel_bw

.. autoclass:: Sel_BW

   
   .. automethod:: __init__

   

   
   
   