mgwr.gwr.GWRResults
===================

.. currentmodule:: mgwr.gwr

.. automethod:: GWRResults.adj_alpha


   