mgwr.gwr.MGWRResults
====================

.. currentmodule:: mgwr.gwr

.. automethod:: MGWRResults.spatial_variability


   