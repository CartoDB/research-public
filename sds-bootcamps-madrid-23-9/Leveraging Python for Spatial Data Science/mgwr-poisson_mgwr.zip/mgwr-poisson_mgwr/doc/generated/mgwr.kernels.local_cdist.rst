mgwr.kernels.local\_cdist
=========================

.. currentmodule:: mgwr

.. autoattribute:: kernels.local_cdist