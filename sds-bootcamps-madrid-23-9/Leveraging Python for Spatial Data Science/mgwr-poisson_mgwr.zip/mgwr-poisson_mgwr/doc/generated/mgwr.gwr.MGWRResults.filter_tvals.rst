mgwr.gwr.MGWRResults
====================

.. currentmodule:: mgwr.gwr

.. automethod:: MGWRResults.filter_tvals


   