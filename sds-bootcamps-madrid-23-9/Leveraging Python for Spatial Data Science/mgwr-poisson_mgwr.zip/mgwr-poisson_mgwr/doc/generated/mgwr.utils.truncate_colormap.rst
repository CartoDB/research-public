mgwr.utils.truncate\_colormap
=============================

.. currentmodule:: mgwr.utils

.. autofunction:: truncate_colormap