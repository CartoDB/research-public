mgwr.gwr.GWRResults
===================

.. currentmodule:: mgwr.gwr

.. automethod:: GWRResults.use_t


   