mgwr.gwr.MGWR
==============

.. currentmodule:: mgwr.gwr

.. automethod:: MGWR.predict


   