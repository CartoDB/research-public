mgwr.kernels.Kernel
===================

.. currentmodule:: mgwr.kernels

.. autoclass:: Kernel

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Kernel.__init__
   
   

   
   
   