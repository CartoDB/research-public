mgwr.gwr.MGWRResults
====================

.. currentmodule:: mgwr.gwr

.. automethod:: MGWRResults.local_collinearity


   