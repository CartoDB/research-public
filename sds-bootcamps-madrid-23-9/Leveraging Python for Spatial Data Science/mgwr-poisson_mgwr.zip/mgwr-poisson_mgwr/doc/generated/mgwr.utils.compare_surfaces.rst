mgwr.utils.compare\_surfaces
============================

.. currentmodule:: mgwr.utils

.. autofunction:: compare_surfaces