mgwr.gwr.GWRResults
===================

.. currentmodule:: mgwr.gwr

.. autoclass:: GWRResults

   
   .. automethod:: __init__


   
   

   
   
   